﻿namespace PModelo
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.btnContaNum = new System.Windows.Forms.Button();
            this.btnPrimeroBranco = new System.Windows.Forms.Button();
            this.btnContaLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(302, 15);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(626, 427);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(196, 200);
            this.lblFrase.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(62, 25);
            this.lblFrase.TabIndex = 1;
            this.lblFrase.Text = "Frase";
            // 
            // btnContaNum
            // 
            this.btnContaNum.Location = new System.Drawing.Point(269, 490);
            this.btnContaNum.Name = "btnContaNum";
            this.btnContaNum.Size = new System.Drawing.Size(179, 66);
            this.btnContaNum.TabIndex = 2;
            this.btnContaNum.Text = "Conta Números";
            this.btnContaNum.UseVisualStyleBackColor = true;
            this.btnContaNum.Click += new System.EventHandler(this.BtnContaNum_Click);
            // 
            // btnPrimeroBranco
            // 
            this.btnPrimeroBranco.Location = new System.Drawing.Point(549, 490);
            this.btnPrimeroBranco.Name = "btnPrimeroBranco";
            this.btnPrimeroBranco.Size = new System.Drawing.Size(189, 66);
            this.btnPrimeroBranco.TabIndex = 3;
            this.btnPrimeroBranco.Text = "Posição 1º espaço em branco";
            this.btnPrimeroBranco.UseVisualStyleBackColor = true;
            this.btnPrimeroBranco.Click += new System.EventHandler(this.BtnPrimeroBranco_Click);
            // 
            // btnContaLetras
            // 
            this.btnContaLetras.Location = new System.Drawing.Point(835, 490);
            this.btnContaLetras.Name = "btnContaLetras";
            this.btnContaLetras.Size = new System.Drawing.Size(180, 66);
            this.btnContaLetras.TabIndex = 4;
            this.btnContaLetras.Text = "Conta letras";
            this.btnContaLetras.UseVisualStyleBackColor = true;
            this.btnContaLetras.Click += new System.EventHandler(this.BtnContaLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1238, 589);
            this.Controls.Add(this.btnContaLetras);
            this.Controls.Add(this.btnPrimeroBranco);
            this.Controls.Add(this.btnContaNum);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.rchtxtFrase);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.Button btnContaNum;
        private System.Windows.Forms.Button btnPrimeroBranco;
        private System.Windows.Forms.Button btnContaLetras;
    }
}