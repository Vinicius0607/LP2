﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void Txtnum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum1.Text, out numero1))
            {
                MessageBox.Show("Número inválido!");
                txtnum1.Focus();
            }
        }

        private void Txtnum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum2.Text, out numero2))
            {
                MessageBox.Show("Número inválido!");
                txtnum2.Focus();
            }
        }

        private void Btnsoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btnsub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btnmult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btndiv_Click(object sender, EventArgs e)
        {
           if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnum2.Focus();
            }
           else
            {
                resultado = numero1 / numero2;
                txtnum3.Text = resultado.ToString();
            }
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtnum3.Clear();
            txtnum1.Focus();

            txtnum1.Text = null;
            txtnum2.Text = null;
            txtnum3.Text = null;
            resultado = 0;
        }

    }
}
