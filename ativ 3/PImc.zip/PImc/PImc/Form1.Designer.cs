﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblaltura = new System.Windows.Forms.Label();
            this.lblimc = new System.Windows.Forms.Label();
            this.mskbxpeso = new System.Windows.Forms.MaskedTextBox();
            this.mskbxaltura = new System.Windows.Forms.MaskedTextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.btncalcular = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblpeso.Location = new System.Drawing.Point(13, 20);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(145, 31);
            this.lblpeso.TabIndex = 0;
            this.lblpeso.Text = "Peso Atual";
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblaltura.Location = new System.Drawing.Point(13, 81);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(85, 31);
            this.lblaltura.TabIndex = 1;
            this.lblaltura.Text = "Altura";
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblimc.Location = new System.Drawing.Point(13, 140);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(64, 31);
            this.lblimc.TabIndex = 2;
            this.lblimc.Text = "IMC";
            // 
            // mskbxpeso
            // 
            this.mskbxpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.mskbxpeso.Location = new System.Drawing.Point(164, 17);
            this.mskbxpeso.Mask = "900.00";
            this.mskbxpeso.Name = "mskbxpeso";
            this.mskbxpeso.Size = new System.Drawing.Size(152, 38);
            this.mskbxpeso.TabIndex = 3;
            this.mskbxpeso.Validated += new System.EventHandler(this.Mskbxpeso_Validated);
            // 
            // mskbxaltura
            // 
            this.mskbxaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.mskbxaltura.Location = new System.Drawing.Point(164, 78);
            this.mskbxaltura.Mask = "0.00";
            this.mskbxaltura.Name = "mskbxaltura";
            this.mskbxaltura.Size = new System.Drawing.Size(152, 38);
            this.mskbxaltura.TabIndex = 4;
            this.mskbxaltura.Validated += new System.EventHandler(this.Mskbxaltura_Validated);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtimc.Location = new System.Drawing.Point(164, 140);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(152, 38);
            this.txtimc.TabIndex = 5;
            // 
            // btncalcular
            // 
            this.btncalcular.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btncalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btncalcular.Location = new System.Drawing.Point(37, 239);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(145, 67);
            this.btncalcular.TabIndex = 6;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = false;
            this.btncalcular.Click += new System.EventHandler(this.Btncalcular_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnlimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnlimpar.Location = new System.Drawing.Point(214, 239);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(145, 67);
            this.btnlimpar.TabIndex = 7;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = false;
            this.btnlimpar.Click += new System.EventHandler(this.Btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnsair.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnsair.Location = new System.Drawing.Point(389, 239);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(145, 67);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = false;
            this.btnsair.Click += new System.EventHandler(this.Btnsair_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.mskbxaltura);
            this.Controls.Add(this.mskbxpeso);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblaltura);
            this.Controls.Add(this.lblpeso);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.MaskedTextBox mskbxpeso;
        private System.Windows.Forms.MaskedTextBox mskbxaltura;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
    }
}

