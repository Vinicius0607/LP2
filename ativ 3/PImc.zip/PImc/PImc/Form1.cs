﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Mskbxpeso_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskbxpeso, "");

            if (!double.TryParse(mskbxpeso.Text, out peso) || (peso <= 0))
            {
                MessageBox.Show("Peso inválido!");
                errorProvider1.SetError(mskbxpeso, "Peso inválido");
            }
        }

        private void Mskbxaltura_Validated(object sender, EventArgs e)
        {
            double altura;
            errorProvider2.SetError(mskbxaltura, "");

            if (!double.TryParse(mskbxaltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inválida!");
                errorProvider2.SetError(mskbxaltura, "Altura inválida");
            }
        }

        private void Btncalcular_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;

            if (double.TryParse(mskbxaltura.Text, out altura) && double.TryParse(mskbxpeso.Text, out peso))
            {
                if ((altura <= 0) || (peso <= 0))
                    MessageBox.Show("Valores devem ser maiores que zero!");
                else
                {
                    imc = peso / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1);
                    txtimc.Text = imc.ToString("");

                    if (imc < 18.5)
                        MessageBox.Show("Classificação: Magreza");
                    else if (imc <= 24.9)
                        MessageBox.Show("Normal");
                    else if (imc <= 29.9)
                        MessageBox.Show("Sobrepeso");
                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade Grave");
                }
            }
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            mskbxaltura.Clear();
            mskbxpeso.Clear();
            txtimc.Clear();
        }
    }
}
